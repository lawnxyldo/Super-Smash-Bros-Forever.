# test-host
just trying to host a discord bot 24/7
